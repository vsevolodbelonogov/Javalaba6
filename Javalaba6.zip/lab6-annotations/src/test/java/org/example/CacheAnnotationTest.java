package org.example;

import org.example.annotations.Cache;
import org.example.model.CachedClass;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CacheAnnotationTest {

    @Test
    void testCacheAreas() {
        Cache ann = CachedClass.class.getAnnotation(Cache.class);
        assertArrayEquals(new String[]{"users", "orders", "products"}, ann.value());
    }

    @Test
    void testEmptyCache() {
        @Cache class Empty {}
        assertEquals(0, Empty.class.getAnnotation(Cache.class).value().length);
    }
}