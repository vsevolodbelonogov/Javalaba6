package org.example;

import org.example.annotations.Default;
import org.example.model.Person;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Тесты @Default")
class DefaultAnnotationTest {

    static Stream<Arguments> data() {
        return Stream.of(
                Arguments.of(Person.class, String.class)
        );
    }

    @ParameterizedTest
    @MethodSource("data")
    void testDefaultValue(Class<?> clazz, Class<?> expected) {
        Default ann = clazz.getAnnotation(Default.class);
        assertNotNull(ann);
        assertEquals(expected, ann.value());
    }
}