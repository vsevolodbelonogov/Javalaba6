package org.example;

import org.example.model.*;
import org.example.processor.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== ЛАБОРАТОРНАЯ РАБОТА №6 — АННОТАЦИИ ===\n");

        System.out.println("1. @Invoke");
        InvokeProcessor.process(new DemoInvoke());

        System.out.println("\n2. @Default");
        DefaultProcessor.process(Person.class);

        System.out.println("\n3. @ToString");
        System.out.println(ToStringProcessor.build(new Person()));

        System.out.println("\n4. @Validate");
        ValidateProcessor.process(ValidatedClass.class);

        System.out.println("\n5. @Two");
        TwoProcessor.process(WithTwo.class);

        System.out.println("\n6. @Cache");
        CacheProcessor.process(CachedClass.class);
        CacheProcessor.process(Person.class);

        System.out.println("\nГотово! Все задачи выполнены.");
    }
}