package org.example.processor;

import org.example.annotations.Invoke;
import java.lang.reflect.Method;

/** Автоматически вызывает методы с @Invoke */
public class InvokeProcessor {
    public static void process(Object obj) {
        if (obj == null) return;
        for (Method m : obj.getClass().getDeclaredMethods()) {
            if (m.isAnnotationPresent(Invoke.class)) {
                m.setAccessible(true);
                try { m.invoke(obj); } catch (Exception ignored) {}
            }
        }
    }
}