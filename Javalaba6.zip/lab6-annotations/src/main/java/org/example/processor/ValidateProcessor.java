package org.example.processor;

import org.example.annotations.Validate;

/** Выводит список классов для валидации */
public class ValidateProcessor {
    public static void process(Class<?> clazz) {
        if (clazz.isAnnotationPresent(Validate.class)) {
            Validate ann = clazz.getAnnotation(Validate.class);
            System.out.print("Валидация: ");
            for (Class<?> c : ann.value()) System.out.print(c.getSimpleName() + " ");
            System.out.println();
        }
    }
}