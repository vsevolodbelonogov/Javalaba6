package org.example.processor;

import org.example.annotations.Cache;

/** Выводит кешируемые области */
public class CacheProcessor {
    public static void process(Class<?> clazz) {
        Cache ann = clazz.getAnnotation(Cache.class);
        if (ann == null) {
            System.out.println("Кеш не настроен");
            return;
        }
        String[] areas = ann.value();
        if (areas.length == 0) {
            System.out.println("Кеш пустой");
        } else {
            System.out.print("Кешируемые области: ");
            for (String s : areas) System.out.print(s + " ");
            System.out.println();
        }
    }
}