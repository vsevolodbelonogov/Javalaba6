package org.example.processor;

import org.example.annotations.Default;

/** Выводит тип по умолчанию */
public class DefaultProcessor {
    public static void process(Class<?> clazz) {
        if (clazz.isAnnotationPresent(Default.class)) {
            Default ann = clazz.getAnnotation(Default.class);
            System.out.println("Тип по умолчанию: " + ann.value().getName());
        }
    }
}