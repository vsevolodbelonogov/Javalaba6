package org.example.processor;

import org.example.annotations.ToString;
import java.lang.reflect.Field;

/** Формирует строковое представление с учётом @ToString */
public class ToStringProcessor {
    public static String build(Object obj) {
        if (obj == null) return "null";
        StringBuilder sb = new StringBuilder(obj.getClass().getSimpleName() + "{");
        boolean first = true;
        for (Field f : obj.getClass().getDeclaredFields()) {
            ToString ann = f.getAnnotation(ToString.class);
            boolean include = ann == null || ann.value() == ToString.Mode.YES;
            if (!include) continue;
            f.setAccessible(true);
            try {
                if (!first) sb.append(", ");
                sb.append(f.getName()).append("=").append(f.get(obj));
                first = false;
            } catch (Exception ignored) {}
        }
        return sb.append("}").toString();
    }
}