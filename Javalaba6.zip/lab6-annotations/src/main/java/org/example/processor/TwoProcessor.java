package org.example.processor;

import org.example.annotations.Two;

/** Читает параметры @Two */
public class TwoProcessor {
    public static void process(Class<?> clazz) {
        if (clazz.isAnnotationPresent(Two.class)) {
            Two ann = clazz.getAnnotation(Two.class);
            System.out.println("first = \"" + ann.first() + "\", second = " + ann.second());
        }
    }
}