package org.example.model;

import org.example.annotations.Cache;

@Cache({"users", "orders", "products"})
public class CachedClass {
}