package org.example.model;

import org.example.annotations.Default;
import org.example.annotations.ToString;

@Default(String.class)
@ToString
public class Person {
    @ToString(value = ToString.Mode.NO)
    private final String password = "secret123";

    private final String name = "Алексей";
    private final int age = 25;

    public String getName() { return name; }
    public int getAge() { return age; }
}