package org.example.model;

import org.example.annotations.Invoke;

public class DemoInvoke {
    @Invoke public void greet() { System.out.println("Привет из @Invoke!"); }
    @Invoke public void info()  { System.out.println("Всё работает!"); }
}