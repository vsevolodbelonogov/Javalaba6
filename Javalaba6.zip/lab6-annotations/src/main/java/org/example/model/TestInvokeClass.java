package org.example.model;

import org.example.annotations.Invoke;

public class TestInvokeClass {
    @Invoke
    public void hello() {
        System.out.println("Привет! Аннотация @Invoke работает!");
    }

    @Invoke
    public void test() {
        System.out.println("Вторая строчка — всё идеально!");
    }
}