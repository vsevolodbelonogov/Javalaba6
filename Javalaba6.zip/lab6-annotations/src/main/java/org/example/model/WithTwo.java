package org.example.model;

import org.example.annotations.Two;

@Two(first = "Hello", second = 2025)
public class WithTwo {
}