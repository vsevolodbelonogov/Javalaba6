package org.example.model;

import org.example.annotations.Validate;

@Validate({String.class, Integer.class, Person.class})
public class ValidatedClass {
}